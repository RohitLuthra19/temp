import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notification-component',
  templateUrl: './notification-component.component.html',
  styleUrls: ['./notification-component.component.css']
})
export class NotificationComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
